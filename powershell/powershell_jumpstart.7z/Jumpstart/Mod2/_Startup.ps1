﻿ise -file ".\1Var.ps1, .\2Quotes.ps1, .\3ObjectMembers.ps1, .\4Parenthesis.ps1,
    .\5If.ps1, .\6Switch.ps1, .\7Do_While.ps1, .\8For_Foreach.ps1"