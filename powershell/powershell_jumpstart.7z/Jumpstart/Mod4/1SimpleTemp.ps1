﻿<#
 Comment based help
#>
Function Verb-Noun {

    [CmdletBinding()]
    Param(
        [Parameter()][String]$MyString,
        [Parameter()][Int]$MyInt
    )

    Begin{<#Code#>}
    Process{<#Code#>}
    End{<#Code#>}
}

