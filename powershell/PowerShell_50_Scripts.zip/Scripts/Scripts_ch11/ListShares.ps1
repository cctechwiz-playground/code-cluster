﻿
$Query = "Select * from win32_share" 
Get-CimInstance -query $Query 

